Koji Typeface
Designed by Zach Bogart

Thanks for purchasing Koji. Hope you enjoy.

*Note*: Some programs (such as Microsoft Word) will not show custom kerning by default for newly-installed fonts. If you experience irregular spacing, please consult the software's preferences to turn on custom kerning.

https://zachbogart.com
2019
Created with FontForge